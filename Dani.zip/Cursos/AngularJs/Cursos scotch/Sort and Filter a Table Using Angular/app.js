var sortApp = angular.module('sortApp',[]);
sortApp.controller('mainController',function($scope){
    $scope.sortType = 'name';
    $scope.sortReverse = false;
    $scope.searchGames = '';

    $scope.games = [
        {name: 'Payerunknown\' Battlegrounds', plataforma:'PC',rating:9},
        {name: 'COD', plataforma:'PS4',rating:8},
        {name: 'Far Cry 5', plataforma:'XBOX',rating:8},
        {name: 'Fornite', plataforma:'PC',rating:6},
        {name: 'Counter Strike', plataforma:'PC',rating:3}
    ];
})