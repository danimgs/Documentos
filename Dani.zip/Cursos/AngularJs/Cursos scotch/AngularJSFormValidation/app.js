/* Creacion de la app de angular */
var validationApp = angular.module('validationApp',[]);

/* Creación del controlador de angular */
validationApp.controller('mainController',function($scope){

    /* Función para enviar los datos del formulario despues de la validación */
    $scope.submitForm= function(isValid){

        /* Comprobar que la que el formulario es valido al completarse */
        if(isValid){
            alert('Formulario realizado correctamente');    
        }
    };
});
