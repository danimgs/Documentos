$.ajax({
    url:'http://services.odata.org/V4/NorthWind/NorthWind.svc/Products?$Select=ProductName',
    success: function(data){
        console.log(data.value[0]);
    }
});