$("li").html("dato");
$("li").css("background-color","green").css("color","brown");
//$("div").text("hola");
$("p:first").text("P Primero")
$(".p2").text("P Segundo")
$(".p3").html("P Tercero").css("color","red");
/*AppendTo --> Función detras de los selectores asignados*/
//$("<p>Este texto va detrás</p>").appendTo("p");
/*AppendTo --> Función delante de los selectores asignados*/
//$("<p>Este texto va delante</p>").prependTo("p");
/*insertBefore*/
$("<p>Esto va antes</p>").insertBefore("p");
/*insertAfter*/
$("<p>Esto va despues</p>").insertAfter(".p2");
/*Nuevos Elementos*/
$(function(){
  $("<a>", { 
    html: "Esto se un <strong>nuevo</strong> link",
    "class": "link",
    href: "page.html"
  });
})();
  
$(".p1").wrap("<div></div>");
/* Eventos */
$("#myinput")
    .on('change',function(ev){
        console.log('la constante unica es el cambio')
    })
    .on('focus',function(ev){
        console.log('el foco es importante')
    });