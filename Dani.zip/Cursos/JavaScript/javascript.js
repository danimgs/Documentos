/* function sayHello(){
    console.log('Hello');
  }
  sayHello();*/
/*
 function sayHello(name){
    console.log('Hello '+name);
  }
  sayHello('bob');
 */

// 
//  setTimeout(function (){
//   	console.log('I waited 2 seconds');
//   },2000);

//Realizar accion cada cierto tiempo
/* let counter = 0;
function timeout(){
	setTimeout(function (){
  		console.log('Tiempo: '+counter++);
		timeout();
  	},1000);
}

timeout(); */

/* let a = [4,8,15,16,23,45];
for (let i=0;i<a.length;i++){
	console.log(a[i]);
} */
/* --------------------- */
/* function one(){
  return 'one';
} */

/* let value=one();
   console.log(value);
*/
/* console.log(one()); */
/* --------------------- */
/* Retornamos una funcion dentro de otra */
/* --------------------- */
/* function three(){
  return function(){
    return 'three';
  }
}

console.log(three()()); */

/* --------------------- */
/* Relacion con objetos */
/* --------------------- */
/* let car = {
  marca: 'bmw',
  modelo: 'm3',
  anyo: '2010',
  precio: function(){
    return 7500;
  },
  descripcion: function(){
    console.log(this.marca + " " + this.modelo);
  }
}

car.descripcion();
console.log("Año: " + car.anyo);

var a = {
  myProperty: { b: 'hi'}
};

console.log(a.myProperty.b); */

/* TEMPLATE LITERALS */
/* let name = 'bob';
console.log(`hi ${name}`); */

/* Constructor de funciones */
/* function Car(make,model,year){
  this.make = make;
  this.model = model;
  this.year = year;
}

let myCar = new Car('bmw','745li',2010);

console.log(myCar);
 */

/* CLASES*/
/* class Car {
  constructor(make,model,year){
    this.make = make;
    this.model = model;
    this.year = year;
  }

  print(){
    console.log(`${this.make} ${this.model} (${this.year})`); 
  }
}

let myCar = new Car ('bmw','745li',2010);
myCar.print();

class SportCar extends Car {
  revEnginer(){
    console.log('El modelo es: ' + this.model);
  }
}

let sportCars = new SportCar('dodge','viper',2012);
sportCars.print();
sportCars.revEnginer(); */

/* FECHAS */
/* let today = new Date();

let bob = new Date('December 7, 1969 07:23:54'); */

/* let bob = new Date('1969-12-07'); */

/* let bob = new Date(1969,11,6); */

/* let bob = new Date(1969,11,6,7,1,23); */

//var elapsedTime = today - bob;
//console.log(elapsedTime);

//get parts
/* console.log(bob.getDate()); //Monday = 1 -- Sunday = 7

console.log(bob.getTime()); */

/* getMonth()
getDate()

getHours()
getMinutes()
getSeconds()
getMilliseconds*/

/* STRING */

/* let primero = 'Este es el apartado del conocimiento de la tennología informática';
let segundo = 'Departamento interno de informática';
let tercero = '4,6,10,25,44,78,98';

let mySplit = tercero.split(',');
console.log(mySplit);

let mySlice = primero.slice(8,19);
console.log(mySlice);

let mySubstring = primero.substr(8,11);
console.log(mySubstring);

let EndWith = segundo.endsWith('tica');
console.log(EndWith);

let startWith = segundo.startsWith('Dep');
console.log(startWith);

let myInclude = segundo.includes('interno');
console.log(myInclude);

let myRepeat = 'Hola! '.repeat(3);
console.log(myRepeat);

let myTrim = '     hundido     ';
console.log(myTrim.length);
console.log(myTrim.trim().length); */

/* ARRAYS */

/* let nombres = ['Daniel','Guillermo','Ana','Jose'];

nombres.forEach((nombre) => console.log(`Nombre ${nombre}` )); */

/* handling error */

function performCalculation(obj){
  if(!obj.hasOwnProperty('b')){
    throw new Error ('Objeto perdido');
  }
  return 6;
}

function performHightLevel(){
  let obj={};
  let value = 0;
  try{
      value = performCalculation(obj);
  }catch (error){
      console.log(error.message);
  }

  if (value==0){

  }
}

performHightLevel();

