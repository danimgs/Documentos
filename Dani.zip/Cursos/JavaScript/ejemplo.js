//Modificar propiedades de objetos
/* var myFirstObject = {};
myFirstObject.firstName = "Andrew";
console.log(myFirstObject.firstName);
myFirstObject.firstName = "Monica";
console.log(myFirstObject.firstName);
myFirstObject["firstName"] = "Catie";
console.log(myFirstObject["firstName"]);
 */

//Añadir métodos a objetos
/*  var cleverMyObject = {
     firstName: "Andrew",
     age: "23",
     myInfo: function(){
        console.log("My name is: " + this.firstName);
        console.log("My age is: "+ this.age);
     }
 };
cleverMyObject.myInfo();  */

//PROPIEDADES DE ENUMERACION
/* var myObject = {
    firstName: "Andrew",
    surName: "Grant",
    age: "23",    
}
for (var prop in myObject) {
    console.log(myObject[propa]);       
} */

//CALLBACKS
var accionQueRealizaCuandoElServerResponde = function(){
    console.log("El servidor responde");
}

function comunicacionConElServidor(callback){
    callback();
}

comunicacionConElServidor(accionQueRealizaCuandoElServerResponde);
