var myCleverObject = {
	firstName: "Andrew",
	age: 21,
	myInfo: function () {
		console.log("My name is " + this.firstName + ". ");
		console.log("My age is " + this.age + ".");
	}
};
myCleverObject.myInfo();