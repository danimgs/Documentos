<?php 
$html = file_get_contents('https://devcode.la/'); //Convierte la información de la URL en cadena
echo $html;
?>