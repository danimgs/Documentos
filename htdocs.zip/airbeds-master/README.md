## Airbeds App

![Airbeds app image](https://i.imgur.com/06wpxko.png)

Airbeds app demos the use of [ReactiveSearch](https://github.com/appbaseio/reactivesearch) for building a search UI.

## Read About It

A how to build post will be available shortly.

## License

The source code is available under MIT License.


