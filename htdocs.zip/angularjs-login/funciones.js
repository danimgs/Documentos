function alineacion(){
    window.location.assign("alineacion.php")
    window.open('alineacion.php','_parent');
}

function mercadoFichajes(){
  window.open('mercadoFichajes.php','_parent');
} 

function irMercado(){
  window.open("mercadoFichajes.php","_parent");
}
function aviso(){
  alert("Hola");
}
function noticias(){
  window.open('noticia.php','_parent');
}
function buscador(){
  window.open('welcome_dashboard.php','_parent');
/*   document.getElementById("buscar").style.display = "inline";
  document.getElementById("tituloBuscar").style.display = "inline"; */
}
function exitSearch(){
  /* document.getElementById("buscar").style.display = "none";
  document.getElementById("tituloBuscar").style.display = "none"; */
  document.getElementById("busqueda").value = "";
  document.getElementById("resultado").innerHTML = "";
}
