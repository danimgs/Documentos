<?php
include("connection.php");
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4"
    crossorigin="anonymous">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
    crossorigin="anonymous">
  <link rel="stylesheet" href="styles.css">
  <!-- SCRIPTS -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
  <script src="funciones.js"></script>
  <title>BET BUILDER</title>
</head>

<body>
  <div class="mt-20" ng-app="AngularJSLogin" ng-controller="AngularLoginController as angCtrl">
    <div id="navbar">
      <a class="active" href="javascript:void(0)">Home</a>
      <a href="javascript:void(0)" onclick="noticias()">Noticias</a>
      <a href="javascript:void(0)" onclick="mercadoFichajes()">Mercado de Fichajes</a>
      <a href="javascript:void(0)" onclick="alineacion()">Alineación</a>
      <a href="javascript:void(0)" onclick="buscador()">Buscador</a>
      
      <div class="buscador" id="buscar">
        <form class="form-inline">
          <input class="form-control bg-white mr-2 rounded" type="text" id="busqueda" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success rounded" type="submit">
            <span class="fa fa-times 9x" onclick="exitSearch()"></span>
          </button>
        </form>
        <div>
          Buscar por:
        </div>
      </div>
      <div class="buscador text-white mr-5" id="tituloBuscar">
        <h3>BUSCADOR DE JUGADORES</h3>
      </div>  

    </div>
  <!-- <div class="header">
    <h2>BUSCADOR DE JUGADORES</h2>
  </div> -->

  <!-- <div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>¡Bienvenido!</strong> Te damos la bienvenida a nuestra página oficial.
  </div> -->
  
    <div id="resultado" class="pt-4" ng-model='angCtrl.inputData.name'></div>
  </div>
  
  <!-- SCRIPTS -->
  <script type="text/javascript">
    $(document).ready(function () {
      var consulta;
      //hacemos focus al campo de búsqueda
      $("#busqueda").focus();

      //comprobamos si se pulsa una tecla
      $("#busqueda").keyup(function (e) {

        //obtenemos el texto introducido en el campo de búsqueda
        consulta = $("#busqueda").val();
        //hace la búsqueda
        $.ajax({
          type: "POST",
          url: "buscar.php",
          data: "b=" + consulta,
          dataType: "html",
          beforeSend: function () {
            //imagen de carga
            $("#resultado").html("<p>Encontrado</p>");
          },
          error: function () {
            alert("error petición ajax");
          },
          success: function (data) {
            $("#resultado").empty();
            $("#resultado").append(data);
          }
        });
      });
    });
  </script>

  <!-- Peticion AJAX -->
  <script>
    angular.module('AngularJSLogin', [])
      .controller('AngularLoginController', ['$scope', '$http', function ($scope, $http) {
        this.loginForm = function () {

          var user_data = 'player_name=' + this.inputData.name;

          $http({
            method: 'POST',
            url: 'guardarJug.php',
            data: user_data,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
          })
            .success(function (data) {
              console.log(data);
              if (data.trim() === 'correct') {
                window.location.href = 'detalle.php';
              } else {
                $scope.errorMsg = "Invalid name";
              }
            })
        }

      }]);
  </script>
  <script>
    window.onscroll = function () { myFunction() };

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function myFunction() {
      if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
      } else {
        navbar.classList.remove("sticky");
      }
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm"
    crossorigin="anonymous"></script>

</body>

</html>