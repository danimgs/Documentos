/* window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}  */  

/* <!-- ?php
require_once 'db_config.php';

$stmt = $DBcon->prepare("SELECT correo, contrasena from usuarios WHERE correo='" . $_POST['user_email'] . "' && contrasena='" . $_POST['user_password'] . "'");
$stmt->execute();
$row = $stmt->rowCount();

if ($row > 0) {
    echo "correct";
    $_SESSION['pass'] = 'contrasena';
    $_SESSION['email'] = 'correo';
} else {
    echo 'wrong';
    echo $contrasena;
}
?> --> */

/*  echo "id: " . $row["id_jugador"]. "<br>".
         "Alias: " . $row["alias"]. "<br>".
        "Puntuacion: " . $row["puntuacion"]. "<br>".
        "Posición: " . $row["posicion"]. "<br>".
        "Equipo: " . $row["nombre"]. "<br>"; */

