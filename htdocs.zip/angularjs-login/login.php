
<?php
include("connection.php");
?>
<?php
session_start();
/* require_once 'db_config.php'; */


$sql = (
    "SELECT correo, contrasena
    FROM usuarios
    WHERE correo='" . $_REQUEST['user_email']."' && contrasena='" .$_REQUEST['user_password'] . "'");


$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "correct";
        $_SESSION['usuario']=$_REQUEST['user_email'];
    }
} else {
    echo "0 results";
}
$conn->close();

?>


