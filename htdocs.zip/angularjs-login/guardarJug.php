<?php
include("connection.php");
?>
<?php
session_start();
/* require_once 'db_config.php'; */


$sql = (
    "SELECT alias
    FROM jugadores
    WHERE alias='" . $_REQUEST['player_name']."'");


$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "correct";
        $_SESSION['nomJug']=$_REQUEST['player_name'];
    }
} else {
    echo "0 results";
}
$conn->close();

?>