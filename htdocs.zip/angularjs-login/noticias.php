<?php
include("connection.php");
include('cabecera.php');
session_start();
?>
    <h1>NOTICIAS</h1>
    <?php

    $sql ="SELECT titulo,descripcion,fecha
            FROM noticias";


    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo 
            "
            <div>
                <div>".$row['titulo']."
                    <div>".$row['fecha']."
                </div>
                <div>".$row['descripcion']."</div>
            </div></br><hr>
            ";
        }
        echo "</table>";
    } else {
        echo "0 results";
    }
    $conn->close();

    ?>
<?php
include('pie.php');
?>