<?php
session_start();
      $buscar = $_POST['b'];
        
      if(!empty($buscar)) {
            buscar($buscar);
      }
        
      function buscar($b) {
            $con = mysqli_connect("localhost","root","");
            mysqli_set_charset($con,'utf8'); 
            mysqli_select_db($con,"betbuilder");
            /* if(isset($_POST['filtro'])){
                  switch($_POST['filtro']){
                    case "jugadores":
                      $sql = 
                        "SELECT alias,dorsal,posicion,precio,puntuacion,e.nombre
                        FROM jugadores j,equipos e
                        WHERE j.id_equipo = e.id_equipo AND alias LIKE '%".$b."%'";
                      break;
                    case "equipo":
                      $sql = 
                      "SELECT alias,dorsal,posicion,precio,puntuacion,e.nombre
                        FROM jugadores j,equipos e
                        WHERE j.id_equipo = e.id_equipo AND nombre LIKE '%".$b."%'";
                      break;
                  }
                }else{
                  $sql = "select * from jugadores;";
                } */
            /* $sql = mysqli_query($con,"SELECT * FROM jugadores WHERE alias LIKE '%".$b."%'"); *//* LIMIT 10 */
            $sql = mysqli_query($con,
              "SELECT id_jugador,alias,dorsal,posicion,precio,npartidos,puntuacion,nombre 
              FROM jugadores j,equipos e
              WHERE j.id_equipo = e.id_equipo AND alias LIKE '%".$b."%'");
            /* $sql = mysqli_query($con,$sql) or trigger_error(mysqli_error($con)); */
            /* $sql ="SELECT j.alias,j.dorsal,j.posicion,j.precio,j.untuacion,e.nombre
            FROM jugadores j,equipos e
            WHERE j.id_equipo = e.id_equipo AND alias LIKE '%".$b."%'" ; */ /* LIMIT 10 */
            
            $contar = @mysqli_num_rows($sql);
            if($contar == 0){
                  echo "No se han encontrado resultados para '<b>".$b."</b>'.";
            }else{
              echo 
              "<table class='table table-striped mt-20'>
                <tr>
                <th>Alias</th>
                <th>Dorsal</th>
                <th>Posicion</th>
                <th>Precio</th>
                <th>Nº Partidos</th>
                <th>Puntuación</th>
                <th>Equipo</th>
                </tr>";
                while($row=mysqli_fetch_array($sql)){
                    $_SESSION['id']=$row['id_jugador'];
                    echo "<tr>";
                    echo "<td><a href='detalle.php' onclick='detalle()' title=$row[id_jugador]>" . $row['alias'] . "</a></td>";
                    echo "<td>" . $row['dorsal'] . "</td>";
                    echo "<td>" . $row['posicion'] . "</td>";
                    echo "<td>" . $row['precio'] . "</td>";
                    echo "<td>" . $row['npartidos'] . "</td>";
                    echo "<td>" . $row['puntuacion'] . "</td>";
                    echo "<td>" . $row['nombre'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
              /* while($row=mysqli_fetch_array($sql)){
               
                $nombre = $row['alias'];
                $dorsal = $row['dorsal'];
                $posicion = $row['posicion'];
                $precio = $row['precio'];
                $puntuacion = $row['puntuacion'];
                $posicion = $row['posicion'];
                echo utf8_decode(
                  "<br>
                  <strong>Nombre: </strong>".
                  "<a href='detalle.php'>".$nombre."</a>".
                  " --- <strong>Dorsal: </strong>".$dorsal.
                  "</a>"." --- <strong>Posici&oacuten: </strong>".$posicion.
                  " --- <strong>Precio: </strong>".$precio.
                  " --- <strong>Puntuaci&oacuten: </strong>".$puntuacion.
                  " --- <strong>Equipo: </strong>".$posicion."</br>");
            } */
            /* Cambiar acentuacion */
            /* https://www.gestiweb.com/?q=content/problemas-html-acentos-y-e%C3%B1es-charset-utf-8-iso-8859-1 */
        }
  }
?>



      
