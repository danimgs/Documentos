<?php
include("connection.php");
?>
<?php
    
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    $conn = new mysqli("localhost", "root", "", "betbuilder");
    mysqli_set_charset($conn,'utf8'); 

    $result = $conn->query("SELECT descripcion,titulo,fecha FROM noticias");

    $array = array();
    while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
        $array[] = $rs;
    }

    $conn->close();
    echo json_encode($array);
?>
