<?php
include("connection.php");
include("cabecera.php");
?>
    <h1>MERCADO DE FICHAJES</h1>
<?php
session_start();
$sql =
    "SELECT j.nomdefecto,e.nombre,j.posicion,j.precio
        FROM jugadores j,equipos e,jug_mercado m
        WHERE j.id_jugador = m.id_jugador AND j.id_equipo = e.id_equipo";

$result = $conn->query($sql);
echo "<table id='merca' class='table table-striped'>
        <thead>
            <tr class='text-white mdb-color darken-3'>
                <th></th>
                <th>Nombre</th>
                <th>Equipo</th>
                <th>Posición</th>
                <th>Precio</th>
            </tr>
        </thead>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "
        <tbody>
            <tr class='plantilla'>
                <td></td>
                <td>".$row['nomdefecto']."</td>
                <td>".$row['nombre']."</td>
                <td>".$row['posicion']."</td>
                <td>".$row['precio']."</td>
            </tr>
        </tbody>";
    }
    echo "</table>";
}
$conn->close();

?>
<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/js/mdb.min.js"></script>
</body>
</html>