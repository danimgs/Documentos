/* SCRIPT */
$(document).ready(function () {
    var consulta;
    //hacemos focus al campo de búsqueda
    $("#busqueda").focus();

    //comprobamos si se pulsa una tecla
    $("#busqueda").keyup(function (e) {

        //obtenemos el texto introducido en el campo de búsqueda
        consulta = $("#busqueda").val();
        //hace la búsqueda
        $.ajax({
            type: "POST",
            url: "buscar.php",
            data: "b=" + consulta,
            dataType: "html",
            beforeSend: function () {
                //imagen de carga
                $("#resultado").html("<p>Encontrado</p>");
            },
            error: function () {
                alert("error petición ajax");
            },
            success: function (data) {
                $("#resultado").empty();
                $("#resultado").append(data);
            }
        });
    });
});

/* PETICION AJAX */
angular.module('AngularJSLogin', [])
    .controller('AngularLoginController', ['$scope', '$http', function ($scope, $http) {
        this.loginForm = function () {

            var user_data = 'player_name=' + this.inputData.name;

            $http({
                method: 'POST',
                url: 'guardarJug.php',
                data: user_data,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            })
                .success(function (data) {
                    console.log(data);
                    if (data.trim() === 'correct') {
                        window.location.href = 'detalle.php';
                    } else {
                        $scope.errorMsg = "Invalid name";
                    }
                })
        }

    }]);

/* SCROLL */
window.onscroll = function () { myFunction() };

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
    if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
    } else {
        navbar.classList.remove("sticky");
    }
}