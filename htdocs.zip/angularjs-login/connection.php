<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "betbuilder";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
//Poner para que aparezcan los acentos y los caracteres raros
mysqli_set_charset($conn,'utf8');  
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 