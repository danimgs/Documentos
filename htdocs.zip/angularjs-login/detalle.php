<?php
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <!-- Font Awesome -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/css/mdb.min.css" rel="stylesheet">
    <link src="styles.css">
    <title>Document</title>
</head>
<body class="container">
    <div class="row">
            <!-- Card -->
            <div class="card testimonial-card col-lg-4 mt-5">

            <!-- Bacground color -->
            <div class="card-up indigo lighten-1"></div>

            <!-- Avatar -->
            <div class="avatar mx-auto white fa fa-user fa-lg pt-5">
            </div>

            <div class="card-body">
                <!-- Name -->
                <h4 class="card-title">
                <?php
                    session_start();
                    $sql =
                        "SELECT nomdefecto,e.nombre
                        FROM jugadores j, equipos e
                        WHERE j.id_equipo = e.id_equipo AND id_jugador = '".$_POST['id']."'";                        

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "Nombre: " . $row['nomdefecto'] . "</br>" .
                                "Equipo: " . $row['nombre'] . "</br>";
                        }
                    }
                    $conn->close();

                    ?>
                </h4>
                <hr>
                <!-- Quotation -->
                <p><i class="fa fa-quote-left"></i>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos, adipisci</p>
            </div>

            </div>
            <!-- Card -->
    </div>
    

<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/js/mdb.min.js"></script>
</body>
</html>