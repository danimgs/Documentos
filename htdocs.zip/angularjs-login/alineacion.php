<?php
include("connection.php");
include("cabecera.php");
session_start();
?>
    <h1>ALINEACIÓN</h1>
<?php

/* $sql=
'SELECT p.id_jugador, j.alias,j.puntuacion,j.posicion,e.nombre
FROM plantilla p, jugadores j,equipos e
WHERE p.id_jugador = j.id_jugador AND j.id_equipo = e.id_equipo
    AND id_usuario IN
        (SELECT id_usuario
        FROM usuarios
        WHERE correo = '.$_SESSION['usuario'].')'; */

$sql ="SELECT p.id_jugador, j.alias,j.puntuacion,j.posicion 'demarcacion',e.nombre,p.posicion 'posicion'
FROM plantilla p, jugadores j,equipos e
WHERE p.id_jugador = j.id_jugador AND j.id_equipo = e.id_equipo
    AND id_usuario IN
        (SELECT id_usuario
        FROM usuarios
        WHERE correo = '".$_SESSION['usuario']."')";


$result = $conn->query($sql);
echo "<table id='example' class='table table-striped'>
        <thead>
            <tr class='text-white mdb-color darken-3'>
                <th>Alias</th>
                <th>Puntuación</th>
                <th>Posición</th>
                <th>Equipo</th>
                <th>Alineado</th>
                <th></th>
            </tr>
        </thead>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "
        <tbody>
            <tr class='plantilla'>
                <td>".$row['alias']."</td>
                <td>".$row['puntuacion']."</td>
                <td>".$row['demarcacion']."</td>
                <td>".$row['nombre']."</td>
                <td>".$row['posicion']."</td>
                <td>
                    <!-- Button trigger modal -->
                    <button type='button' class='btn mdb-color   darken-3' data-toggle='modal' data-target='#exampleModal'>
                        Alinear
                    </button>
                    <div class='modal fade' id='exampleModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                        <div class='modal-dialog' role='document'>
                            <div class='modal-content'>
                                <div class='modal-header'>
                                    <h5 class='modal-title' id='exampleModalLabel'>Modal title</h5>
                                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                        <span aria-hidden='true'>&times;</span>
                                    </button>
                                </div>
                                <div class='modal-body'>
                                    ¿Quieres alinear a ".$row['alias']." a tu 11 inicial?
                                </div>
                                <div class='modal-footer'>
                                    <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                                    <button type='button' class='btn btn-primary'>Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>                                    
                </td>
            </tr>
        </tbody>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();

?>
<h1>11 INICIAL</h1>
    <div class="main-container-campo">
        <div class="container-futbol">
            <div class="jugador-campo" onclick='aviso()'></div>
        </div>
        <div class="container-futbol">
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
        </div>
        <div class="container-futbol">
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
        </div>
        <div class="container-futbol">
            <div class="jugador-campo"></div>
            <div class="jugador-campo"></div>
        </div>
    </div>
    

    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.0/js/mdb.min.js"></script>
<?php
    include("pie.php");
?>
