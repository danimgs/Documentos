<?php

class Duck extends Eloquent {

	protected $fillable = array('name', 'email', 'password');

}