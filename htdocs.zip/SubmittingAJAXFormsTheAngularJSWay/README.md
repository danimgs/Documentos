# Submitting Forms: The AngularJS Way

Code to complement the tutorial: [Submitting Forms: The AngularJS Way](http://scotch.io/tutorials/javascript/submitting-ajax-forms-the-angularjs-way)

A look at processing AJAX forms using jQuery vs Angular.
