﻿<?php require("connection.php"); ?>
<?php 
	if(isset($_POST['filtro'])){
		switch($_POST['filtro']){
			case "todos":
				$sql = "select * from jugadores;";
				break;
			case "madrid":
				$sql = 
				"select alias,dorsal,precio,puntuacion,e.nombre
				from jugadores j,equipos e
				where j.id_equipo = e.id_equipo;";
				break;
			case "antiguos":
				$sql = "select * from calendario order by dia desc;";
				break;
			case "caros":
				$sql = "select * from jugadores order by precio desc;";
				break;
			case "economicos":
				$sql = /* mysqli_query($link,  */"select * from jugadores order by precio asc;"/* ) */;
				break;
		}
	}else{
		$sql = "select * from jugadores;";
	}
?>

<?php include("templates/header.php"); ?>
<h1>Crear Filtros de Productos en Php y Mysql</h1>
<h3>Listado de Productos</h3>
<div id="filtros">
Selecciona los filtros deseados para encontrar los productos 
<form action="index.php" method="post">
	<select name="filtro" >
		<option value="todos"></option>
		<option value="madrid">Jugadores del Real Madrid</option>
			<!-- <select name="posicion">
				<option value="POR">Portero</option>
				<option value="DF">Defensa</option>
				<option value="MC">Mediocentro</option>
				<option value="DEL">Delantero</option>
			</select> -->
		<option value="antiguos">Partidos Antiguos</option>
		<option value="caros">Jugadores más Caros</option>
		<option value="economicos">Jugadores Economicos</option>
	</select>
	<button type="submit">Filtrar</button></form>
</div>
<div id="productos">
	<?php
		/* $result = mysqli_query($sql,$link); */
		$result = mysqli_query( $link,$sql) or trigger_error(mysqli_error($link));
		if(!$result )
		{
		 	die('Ocurrio un error al obtener los valores de la base de datos: '.mysqli_error($link));
		}
		echo "<center>
				<table>
					<tr>
						<th>Alias</th>
						<th>Dorsal</th>
						<th>Precio</th>
						<th>Puntuación</th>
						<th>Nombre</th>
					</tr>";

		while($row = mysqli_fetch_array($result))
		{
			echo 	"<tr>".
						"<td>{$row['alias']} </td> ".
						"<td>{$row['dorsal']} </td> ".
						"<td>{$row['precio']} </td> ".
						"<td>{$row['puntuacion']} </td>".
						"<td>{$row['nombre']} </td> ".
					"</tr>";
		} 
		echo 	"</table>
			</center>";
		mysqli_close($link);
	?>
</div>
<?php include("templates/footer.php"); ?>