<!--?php
$servername = "localhost";
$username = "root";
$password = "";

$link = mysqli_connect($servername,$username,$password);
mysqli_select_db($link,"betbuilder");
?> -->

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName="betbuilder";
// 1. Create a database connection
$link = mysqli_connect($servername,$username,$password);
if (!$link) {
    die("Database connection failed: " . mysqli_connect_error());
}

// 2. Select a database to use 
$db_select = mysqli_select_db($link, $dbName);
if (!$db_select) {
    die("Database selection failed: " . mysqli_error($link));
}
?>