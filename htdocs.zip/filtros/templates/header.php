<!DOCTYPE html>
<html lang="es">
<head>
<title>Crear filtros de Productos en php y mysql</title>
<link rel="stylesheet" type="text/css" href="resources/style.css">
</head>
<body>
	<nav>
		<ul>
			<li><a href="#">MENU 1</a></li>
			<li><a href="#">MENU 1</a></li>
			<li><a href="#">MENU 1</a></li>
			<li><a href="#">MENU 1</a></li>
			<li><a href="#">MENU 1</a></li>
		</ul>
	</nav>